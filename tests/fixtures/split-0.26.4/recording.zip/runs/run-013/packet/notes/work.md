Native observation in /Users/example/checkout; no guest checkout exists.
